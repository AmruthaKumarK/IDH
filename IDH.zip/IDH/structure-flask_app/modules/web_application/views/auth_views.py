from flask import render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, current_user, login_required
from flask_dance.contrib.google import google
from app import db
from app.models import User
from app import app

@app.route('/login')
def google_login():
    if not google.authorized:
        return redirect(url_for('google.login'))
    
    resp = google.get('/plus/v1/people/me')
    assert resp.ok, resp.text
    user_info = resp.json()
    user = User.query.filter_by(email=user_info['emails'][0]['value']).first()
    if user is None:
        user = User(
            name=user_info['displayName'],
            email=user_info['emails'][0]['value'],
            profile_picture=user_info['image']['url'],
            social_login_provider='Google'
        )
        db.session.add(user)
        db.session.commit()

    login_user(user)
    return redirect(url_for('web_application.dashboard'))

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('web_application.index'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')
