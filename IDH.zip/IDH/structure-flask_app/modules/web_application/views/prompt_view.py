from flask import render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db
from app.models import PromptLog
from langchain.chains import LLMChain
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from app import app

@app.route('/prompts', methods=['GET', 'POST'])
@login_required
def create_prompt():
    if request.method == 'POST':
        prompt_text = request.form.get('prompt')
        if not prompt_text:
            flash("Please enter a prompt.", "danger")
            return redirect(url_for('web_application.create_prompt'))
        
        llm = OpenAI(model="text-davinci-003")
        prompt = PromptTemplate(input_variables=["question"], template="{question}")
        chain = LLMChain(llm=llm, prompt=prompt)
        generated_output = chain.run(question=prompt_text)
        
        prompt_log = PromptLog(
            prompt_text=prompt_text,
            generated_output=generated_output,
            created_by_user_id=current_user.id
        )
        db.session.add(prompt_log)
        db.session.commit()
        
        flash("Prompt created successfully!", "success")
        return redirect(url_for('web_application.view_prompts'))
    
    return render_template('create_prompt.html')

@app.route('/prompts/view')
@login_required
def view_prompts():
    prompt_logs = PromptLog.query.filter_by(created_by_user_id=current_user.id).all()
    return render_template('view_prompts.html', prompt_logs=prompt_logs)
