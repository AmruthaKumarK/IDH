from flask import render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db
from app.models import ScrapedData
from app.utils.scraper import scrape_url  # Assuming you have a scrape_url function
from app import app

@app.route('/scrape', methods=['GET', 'POST'])
@login_required
def scrape():
    if request.method == 'POST':
        url = request.form.get('url')
        if not url:
            flash("Please enter a URL.", "danger")
            return redirect(url_for('web_application.scrape'))

        try:
            scraped_data = scrape_url(url)
            data = ScrapedData(
                url=url,
                content=scraped_data['content'],
                metadata=scraped_data['metadata'],
                created_by_user_id=current_user.id
            )
            db.session.add(data)
            db.session.commit()

            flash("Data scraped and saved successfully!", "success")
            return redirect(url_for('web_application.view_scraped_data'))
        except Exception as e:
            flash(f"Error scraping the URL: {str(e)}", "danger")
            return redirect(url_for('web_application.scrape'))

    return render_template('scrape_url.html')

@app.route('/scraped_data')
@login_required
def view_scraped_data():
    scraped_data = ScrapedData.query.filter_by(created_by_user_id=current_user.id).all()
    return render_template('view_scraped_data.html', scraped_data=scraped_data)
