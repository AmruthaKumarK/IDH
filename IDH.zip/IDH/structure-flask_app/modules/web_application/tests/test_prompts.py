import unittest
from app import create_app, db
from app.models import User, PromptLog
from flask_login import login_user
from flask import url_for
from langchain.chains import LLMChain
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate

class PromptTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app('testing')
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()

        # Create a test user
        user = User(name="Test User", email="testuser@example.com")
        db.session.add(user)
        db.session.commit()

        # Log in test user
        self.user = user
        login_user(self.user)

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.app_context.pop()

    def test_prompt_creation(self):
        """Test creating and storing prompts"""
        prompt_text = "What is the capital of France?"
        llm = OpenAI(model="text-davinci-003")
        prompt = PromptTemplate(input_variables=["question"], template="{question}")
        chain = LLMChain(llm=llm, prompt=prompt)

        # Generate the response
        generated_output = chain.run(question=prompt_text)

        # Save the prompt and generated output
        prompt_log = PromptLog(prompt_text=prompt_text, generated_output=generated_output, created_by_user_id=self.user.id)
        db.session.add(prompt_log)
        db.session.commit()

        # Retrieve and check the stored data
        prompt_log = PromptLog.query.first()
        self.assertIsNotNone(prompt_log)
        self.assertEqual(prompt_log.prompt_text, prompt_text)
        self.assertEqual(prompt_log.generated_output, generated_output)
        self.assertEqual(prompt_log.created_by_user_id, self.user.id)

    def test_prompt_log_api(self):
        """Test API for retrieving prompt logs"""
        # Create a prompt and log
        prompt_text = "What is the capital of Spain?"
        generated_output = "Madrid"
        prompt_log = PromptLog(prompt_text=prompt_text, generated_output=generated_output, created_by_user_id=self.user.id)
        db.session.add(prompt_log)
        db.session.commit()

        # Test API response
        response = self.client.get(url_for('web_application.get_prompt_logs'))
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertGreater(len(data), 0)
        self.assertEqual(data[0]['prompt_text'], prompt_text)
        self.assertEqual(data[0]['generated_output'], generated_output)
