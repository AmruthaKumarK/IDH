import unittest
from app import create_app, db
from app.models import User, ScrapedData
from flask_login import login_user
from flask import url_for
from app.utils.scraper import scrape_url  # Assuming you have a scrape_url function

class ScrapingTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app('testing')
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()

        # Create a test user
        user = User(name="Test User", email="testuser@example.com")
        db.session.add(user)
        db.session.commit()

        # Log in test user
        self.user = user
        login_user(self.user)

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.app_context.pop()

    def test_scrape_url(self):
        """Test scraping a URL"""
        url = "https://example.com"  # Example URL
        data = scrape_url(url)
        
        # Simulating the scraper storing data
        scraped_data = ScrapedData(
            url=url,
            content=data['content'],
            metadata=data['metadata'],
            created_by_user_id=self.user.id
        )
        db.session.add(scraped_data)
        db.session.commit()

        # Retrieve and check the stored data
        scraped_data = ScrapedData.query.first()
        self.assertIsNotNone(scraped_data)
        self.assertEqual(scraped_data.url, url)
        self.assertEqual(scraped_data.created_by_user_id, self.user.id)
