import unittest
from app import create_app, db
from app.models import User
from flask_login import current_user
from flask import url_for
from flask_dance.contrib.google import google

class AuthTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app('testing')
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.app_context.pop()

    def test_google_login(self):
        """Test Google OAuth login"""
        with self.client:
            response = self.client.get(url_for('web_application.google_login'))
            self.assertEqual(response.status_code, 302)  # Expecting redirect

            # Simulating user logged in through Google
            with google.tokengetter:
                google.tokengetter = lambda: {'access_token': 'mock_access_token'}
            response = self.client.get(url_for('web_application.google_login'))
            self.assertEqual(response.status_code, 200)
            user = User.query.first()
            self.assertIsNotNone(user)
            self.assertEqual(user.name, "Mock User")

    def test_logout(self):
        """Test user logout"""
        with self.client:
            self.client.get(url_for('web_application.google_login'))  # Simulate login
            self.client.get(url_for('web_application.logout'))  # Simulate logout
            self.assertIsNone(current_user.get_id())
