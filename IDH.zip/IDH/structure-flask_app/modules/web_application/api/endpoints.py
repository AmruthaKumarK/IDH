from flask import Blueprint, jsonify, request
from modules.web_application.models.models import db, ScrapedData, PromptLog

api_bp = Blueprint("api", __name__, url_prefix="/api")

@api_bp.route("/scraped_data", methods=["GET"])
def get_scraped_data():
    data = ScrapedData.query.all()
    return jsonify([
        {
            "id": item.id,
            "url": item.url,
            "content": item.content,
            "metadata": item.metadata,
            "created_at": item.created_at,
            "user_id": item.created_by_user_id
        }
        for item in data
    ])

@api_bp.route("/prompts", methods=["GET"])
def get_prompts():
    prompts = PromptLog.query.all()
    return jsonify([
        {
            "id": log.id,
            "prompt_text": log.prompt_text,
            "generated_output": log.generated_output,
            "tokens_used": log.tokens_used,
            "created_at": log.created_at,
            "user_id": log.created_by_user_id
        }
        for log in prompts
    ])

@api_bp.route("/scraped
