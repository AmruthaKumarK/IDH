// Scroll to top button functionality
const scrollToTopButton = document.getElementById('scrollToTopBtn');

window.onscroll = function() {
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
        scrollToTopButton.style.display = 'block';
    } else {
        scrollToTopButton.style.display = 'none';
    }
};

scrollToTopButton.addEventListener('click', function() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Form validation for scraping URL (Ensure URL is valid)
const scrapeForm = document.getElementById('scrapeForm');
if (scrapeForm) {
    scrapeForm.addEventListener('submit', function(event) {
        const urlField = document.getElementById('urlField');
        const urlPattern = /^(https?:\/\/)?([a-z0-9]+\.)+[a-z]{2,6}([\/\w .-]*)*\/?$/;
        const urlValue = urlField.value;
        
        if (!urlPattern.test(urlValue)) {
            alert('Please enter a valid URL.');
            event.preventDefault();
        }
    });
}

// Handle login form submission (for demo purposes)
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', function(event) {
        const emailField = document.getElementById('email');
        const passwordField = document.getElementById('password');

        if (!emailField.value || !passwordField.value) {
            alert('Both email and password are required.');
            event.preventDefault();
        }
    });
}

// Handle registration form submission (for demo purposes)
const registerForm = document.getElementById('registerForm');
if (registerForm) {
    registerForm.addEventListener('submit', function(event) {
        const nameField = document.getElementById('name');
        const emailField = document.getElementById('email');
        const passwordField = document.getElementById('password');

        if (!nameField.value || !emailField.value || !passwordField.value) {
            alert('All fields are required.');
            event.preventDefault();
        }
    });
}
