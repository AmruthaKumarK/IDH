# Flask Web Application

A Flask web application for scraping data, using LangChain for generating responses from prompts, and integrating social login via Google OAuth.

## Setup

1. Clone the repository
2. Create a `.env` file and add your credentials (e.g., `GOOGLE_OAUTH_CLIENT_ID`, `GOOGLE_OAUTH_CLIENT_SECRET`).
3. Run Docker Compose:
    ```
    docker-compose up
    ```
4. Visit `http://localhost:5000` in your browser.

## Features

- Google OAuth login
- URL scraping and data storage
- LangChain prompt generation
