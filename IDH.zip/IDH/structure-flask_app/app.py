from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_dance.contrib.google import make_google_blueprint

app = Flask(__name__)
app.config.from_object('config.config.Config')

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'google.login'

google_bp = make_google_blueprint(client_id=app.config['GOOGLE_OAUTH_CLIENT_ID'],
                                  client_secret=app.config['GOOGLE_OAUTH_CLIENT_SECRET'],
                                  redirect_to='google_login')
app.register_blueprint(google_bp, url_prefix='/google_login')

from modules.web_application.views import auth_views, scraping_views, prompt_views
from app.models import User

if __name__ == "__main__":
    app.run(debug=True)
